/*
# <<BEGIN-copyright>>
# <<END-copyright>>
*/
#ifndef MCGIDI_private_h_included
#define MCGIDI_private_h_included

#if defined __cplusplus
    extern "C" {
    namespace GIDI {
#endif

#define MCGIDI_token_productFrame "productFrame"

#if defined __cplusplus
    }
    }
#endif

#endif          /* End of MCGIDI_private_h_included. */
